#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 tools/run_all.py
python3 tools/check_kicad.py
printf '\nOpen results/index.html in your browser to view all waveforms.\n'
