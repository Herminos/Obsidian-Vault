#!/usr/bin/env python3
"""Run ngspice cases, measure settled waveforms, export CSV, SVG and HTML."""
import csv, html, json, math, pathlib, shutil, statistics, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
CASES=[
 ('baseline','基准 2.8 kHz',10000,20000,5.1,5.1,0,0),
 ('ratio_low','R1/R2 ≈ 0.402',10000,24900,5.1,5.1,0,0),
 ('ratio_high','R1/R2 = 0.60',12000,20000,5.1,5.1,0,0),
 ('zener_asym','稳压限幅 +3.3 / −5.1 V',10000,20000,3.3,5.1,0,0),
 ('us_positive','Us = +1 V',10000,20000,5.1,5.1,1,0),
 ('us_negative','Us = −1 V',10000,20000,5.1,5.1,-1,0),
 ('un_positive','UN = +1 V',10000,20000,5.1,5.1,0,1),
 ('un_negative','UN = −1 V',10000,20000,5.1,5.1,0,-1),
]
FIELDS=['case','label','R1_ohm','R2_ohm','UZP_V','UZM_V','Us_V','UN_V','theory_f_Hz','sim_f_Hz','theory_T_us','sim_T_us','theory_max_V','sim_max_V','theory_min_V','sim_min_V','theory_square_duty_pct','sim_square_duty_pct','sim_triangle_positive_pct','frequency_error_pct']

def theory(r1,r2,p,m,us,un):
 r=r1/r2; span=r*(p+m); rc=17800*1e-8
 period=span*rc*(1/(p-us)+1/(m+us))
 return dict(f=1/period,T=period,hi=(1+r)*un+r*m,lo=(1+r)*un-r*p,duty=(m+us)/(p+m))

def circuit(case,step='0.2u'):
 key,label,r1,r2,p,m,us,un=case
 return f'''Triangle oscillator - {key} (student 2025111871)
.include models.lib
.param RONE={r1} RTWO={r2} RT=17.8k CAP=10n UZP={p} UZM={m} US={us} UN={un}
Vref un 0 {{UN}}
Vbias us 0 {{US}}
X1 up un a1 EDU_OPAMP
R3 a1 sq 1k
Xz sq 0 EDU_CLAMP UZP={{UZP}} UZM={{UZM}}
R1 tri up {{RONE}}
R2 sq up {{RTWO}}
R4 sq inv {{RT}}
C1 inv tri {{CAP}} IC=0.01
X2 us inv tri EDU_OPAMP
R5 us 0 10k
.options reltol=1e-5 abstol=1e-10 vntol=1e-7
.tran {step} 8m uic
.control
run
set numdgt=15
set wr_singlescale
set wr_vecnames
wrdata results/{key}.dat v(tri) v(sq) v(up)
quit
.endc
.end
'''

def crossings(t,y,rising=True):
 out=[]
 for i in range(1,len(t)):
  a,b=y[i-1],y[i]
  if (a<0<=b) if rising else (a>0>=b):
   out.append(t[i-1]+(t[i]-t[i-1])*(-a)/(b-a))
 return out

def measure(path):
 with path.open() as f:
  next(f); rows=[tuple(map(float,line.split())) for line in f if line.strip()]
 if rows[-1][0]<0.007999: raise RuntimeError('Transient incomplete: '+str(path))
 rows=[r for r in rows if r[0]>=0.003]
 t=[r[0] for r in rows]; tri=[r[1] for r in rows]; sq=[r[2] for r in rows]
 rise=crossings(t,sq); fall=crossings(t,sq,False)
 if len(rise)<5: raise RuntimeError('No stable oscillation: '+str(path))
 periods=[b-a for a,b in zip(rise,rise[1:])]
 period=statistics.mean(periods)
 duty=statistics.mean((next(f for f in fall if f>a)-a)/(b-a) for a,b in zip(rise,rise[1:]))
 # Integrate triangle-positive time only over complete settled cycles.
 positive=0; total=rise[-1]-rise[0]
 for i in range(1,len(t)):
  a,b=t[i-1],t[i]; ya,yb=tri[i-1],tri[i]
  if b<=a or b<=rise[0] or a>=rise[-1]: continue
  lo=max(a,rise[0]); hi=min(b,rise[-1]); yl=ya+(yb-ya)*(lo-a)/(b-a); yh=ya+(yb-ya)*(hi-a)/(b-a)
  if yl>=0 and yh>=0: positive+=hi-lo
  elif yl*yh<0:
   z=lo+(hi-lo)*(-yl)/(yh-yl);positive+=(hi-z if yh>0 else z-lo)
 return dict(f=1/period,T=period,hi=max(tri),lo=min(tri),duty=duty,tri_positive=positive/total,jitter=max(periods)-min(periods)),rows

def plot_svg(path,label,rows,th):
 selected=[r for r in rows if .005<=r[0]<=.0065][::2]
 w,h=1080,480;left,right,top,bottom=80,1045,70,410
 ymin,ymax=-7,7
 def x(t):return left+(t-.005)/.0015*(right-left)
 def y(v):return bottom-(v-ymin)/(ymax-ymin)*(bottom-top)
 parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}"><rect width="1080" height="480" fill="#fff"/><style>text{{font-family:sans-serif;fill:#24334b}}</style>',f'<text x="30" y="32" font-size="22">{html.escape(label)}</text>']
 for v in range(-6,7,2):parts += [f'<path d="M{left} {y(v)} H{right}" stroke="#dce3ec"/><text x="35" y="{y(v)+5}" font-size="15">{v} V</text>']
 for j in range(7):
  t=.005+j*.00025; parts += [f'<path d="M{x(t)} {top} V{bottom}" stroke="#edf0f5"/><text x="{x(t)-18}" y="440" font-size="14">{t*1000:.2f}</text>']
 for idx,color,name in [(1,'#1465cf','Triangle uo'),(2,'#e88718','Square uo1')]:
  points=' '.join(f'{x(r[0]):.2f},{y(r[idx]):.2f}' for r in selected)
  parts += [f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2"/>']
 parts += ['<text x="900" y="470" font-size="16">Time (ms)</text>','<text x="85" y="57" font-size="15" fill="#1465cf">Blue: triangle</text><text x="280" y="57" font-size="15" fill="#e88718">Orange: square</text>','</svg>']
 path.write_text(''.join(parts))

def main():
 if not shutil.which('ngspice'):sys.exit('Install ngspice first')
 (ROOT/'results').mkdir(exist_ok=True);(ROOT/'circuits').mkdir(exist_ok=True)
 summaries=[]
 for case in CASES:
  key,label,r1,r2,p,m,us,un=case; net=circuit(case)
  # Paths resolve from project root. The copies in circuits are for reference.
  (ROOT/'circuits'/f'{key}.cir').write_text(net)
  active=ROOT/'current.cir';active.write_text(net)
  proc=subprocess.run(['ngspice','-b',str(active)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (ROOT/'results'/f'{key}.log').write_text(proc.stdout)
  if proc.returncode or 'aborted' in proc.stdout or 'Timestep too small' in proc.stdout:raise RuntimeError(proc.stdout)
  sim,rows=measure(ROOT/'results'/f'{key}.dat'); th=theory(r1,r2,p,m,us,un)
  err=(sim['f']/th['f']-1)*100
  assert abs(err)<1, (key,err)
  assert abs(sim['hi']-th['hi'])<.06 and abs(sim['lo']-th['lo'])<.06
  assert abs(sim['duty']-th['duty'])<.005
  assert sim['jitter']/sim['T']<.01
  row=[key,label,r1,r2,p,m,us,un,th['f'],sim['f'],th['T']*1e6,sim['T']*1e6,th['hi'],sim['hi'],th['lo'],sim['lo'],th['duty']*100,sim['duty']*100,sim['tri_positive']*100,err]
  summaries.append(dict(zip(FIELDS,row)))
  plot_svg(ROOT/'results'/f'{key}.svg',label,rows,th)
  print(f'{key:16} f={sim["f"]:9.3f} Hz, T={sim["T"]*1e6:.3f} us, range=[{sim["lo"]:.4f}, {sim["hi"]:.4f}] V, duty={sim["duty"]*100:.2f}%')
 with (ROOT/'results'/'measurements.csv').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=FIELDS);writer.writeheader();writer.writerows(summaries)
 (ROOT/'results'/'measurements.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2))
 # Time-step convergence test on baseline: halve the maximum timestep.
 active.write_text(circuit(CASES[0], '0.1u').replace('results/baseline.dat','results/convergence.dat'))
 proc=subprocess.run(['ngspice','-b',str(active)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (ROOT/'results'/'convergence.log').write_text(proc.stdout)
 if 'aborted' in proc.stdout: raise RuntimeError(proc.stdout)
 refined,_=measure(ROOT/'results'/'convergence.dat')
 delta=abs(refined['f']/summaries[0]['sim_f_Hz']-1)*100
 assert delta<.1
 (ROOT/'results'/'validation.txt').write_text(f'8 cases completed to 8ms; settled data >=3ms.\nFrequency theory error <1%; peak errors <60mV; square duty error <0.5 percentage points.\nHalf-timestep baseline frequency change: {delta:.6f}% (<0.1%).\nAll checks passed.\n')
 active.write_text(circuit(CASES[0]))
 # A self-contained results viewer. SVG images stay beside this file.
 options=''.join(f'<option value="{r["case"]}">{html.escape(r["label"])}</option>' for r in summaries)
 page='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>三角波发生器 · 2025111871</title><style>body{font-family:system-ui,sans-serif;max-width:1120px;margin:35px auto;padding:0 20px;color:#24334b;background:#f5f7fb}h1{font-size:28px}select,button{padding:10px;font-size:17px;margin-right:10px}img{width:100%;background:white}table{width:100%;border-collapse:collapse;background:white;margin:20px 0}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left}p{line-height:1.8}.note{font-size:14px}</style><h1>三角波 / 方波发生器：参数如何改变波形</h1><p>学号 2025111871 · 目标 2800 Hz · R₁ 10kΩ、R₂ 20kΩ、R₄ 17.8kΩ、C 10nF<br>ngspice 瞬态计算结果；展示稳态 5–6.5 ms。运放和稳压限幅采用教学行为模型。</p><select id="case">OPTIONS</select><button onclick="next()">下一组</button><img id="wave"><table><thead><tr><th>指标</th><th>理论</th><th>仿真</th></tr></thead><tbody id="metrics"></tbody></table><p class="note">占空比定义为方波 uo1 的高电平时间 / 周期；三角波大于 0 V 的时间比例另列。Us 为积分器正输入偏置，UN 为比较器参考电压。本页面展示已完成的仿真结果，更改选项不会重新计算；运行 ../run.sh 重新仿真。</p><p><a href="measurements.csv">下载完整参数表 CSV</a> · <a href="validation.txt">查看验证结果</a> · <a href="../schematic.svg">查看电路图</a></p><script>const data=DATA;const sel=document.getElementById('case');function show(){const r=data.find(x=>x.case===sel.value);document.getElementById('wave').src=r.case+'.svg';const fields=[['频率 Hz','theory_f_Hz','sim_f_Hz'],['周期 μs','theory_T_us','sim_T_us'],['正向峰值 V','theory_max_V','sim_max_V'],['负向峰值 V','theory_min_V','sim_min_V'],['方波高电平占空比 %','theory_square_duty_pct','sim_square_duty_pct']];document.getElementById('metrics').innerHTML=fields.map(([n,a,b])=>`<tr><td>${n}</td><td>${r[a].toFixed(3)}</td><td>${r[b].toFixed(3)}</td></tr>`).join('')+`<tr><td>三角波大于 0 V 的时间比例 %</td><td>—</td><td>${r.sim_triangle_positive_pct.toFixed(3)}</td></tr>`;}function next(){sel.selectedIndex=(sel.selectedIndex+1)%sel.options.length;show()}sel.onchange=show;show();</script></html>'''
 page=page.replace('OPTIONS',options).replace('DATA',json.dumps(summaries,ensure_ascii=False))
 (ROOT/'results'/'index.html').write_text(page)
 print(f'Validation passed; convergence change {delta:.6f}%. Results: {ROOT}/results/index.html')
if __name__=='__main__':main()
