#!/usr/bin/env python3
"""Generate a self-contained KiCad schematic with embedded symbol definitions."""
import pathlib,uuid,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
def uid():return str(uuid.uuid4())
def q(s):return json.dumps(str(s),ensure_ascii=False)
def effects(size=1.27,hide=False):return f'(effects (font (size {size} {size}))'+(' (hide yes)' if hide else '')+')'
def prop(n,v,x,y,hide=False):return f'(property {q(n)} {q(v)} (at {x} {y} 0) {effects(hide=hide)})'
def pin(n,x,y,angle,length=2.54,kind='passive'):
 return f'(pin {kind} line (at {x} {y} {angle}) (length {length}) (name {q(n)} {effects()}) (number {q(n)} {effects()}))'
def lib(name,ref,value,shape,pins):
 return f'''(symbol "Edu:{name}" (pin_names (offset 0.508) (hide yes)) (pin_numbers (hide yes)) (exclude_from_sim no) (in_bom yes) (on_board yes)
 {prop('Reference',ref,0,5)} {prop('Value',value,0,-5)}
 (symbol "{name}_0_1" {shape}) (symbol "{name}_1_1" {''.join(pins)}))'''
rect='(rectangle (start -2.54 -1.27) (end 2.54 1.27) (stroke (width 0.254) (type default)) (fill (type none)))'
cap=''.join(f'(polyline (pts (xy {x} -2.54) (xy {x} 2.54)) (stroke (width 0.254) (type default)) (fill (type none)))' for x in [-.635,.635])
circle='(circle (center 0 0) (radius 2.54) (stroke (width 0.254) (type default)) (fill (type none)))'
tri='(polyline (pts (xy -5.08 5.08) (xy -5.08 -5.08) (xy 5.08 0) (xy -5.08 5.08)) (stroke (width 0.254) (type default)) (fill (type none)))'
tri+='(text "+" (at -3.8 2.54 0) (effects (font (size 1.27 1.27))))(text "-" (at -3.8 -2.54 0) (effects (font (size 1.27 1.27))))'
libs=[lib('R','R','R',rect,[pin('1',-5.08,0,0),pin('2',5.08,0,180)]),lib('C','C','C',cap,[pin('1',-5.08,0,0,4.445),pin('2',5.08,0,180,4.445)]),lib('V','V','V',circle,[pin('1',-5.08,0,0),pin('2',5.08,0,180)]),lib('Clamp','X','EDU_CLAMP',rect,[pin('1',-5.08,0,0),pin('2',5.08,0,180)]),lib('Amp','X','EDU_OPAMP',tri,[pin('1',-7.62,2.54,0,kind='input'),pin('2',-7.62,-2.54,0,kind='input'),pin('3',7.62,0,180,kind='output')])]
rootid=uid();items=[]
def wire(a,b):
 items.append(f'(wire (pts (xy {a[0]} {a[1]}) (xy {b[0]} {b[1]})) (stroke (width 0) (type default)) (uuid {uid()}))')
def label(n,x,y):
 items.append(f'(global_label {q(n)} (shape input) (at {x} {y} 0) {effects()} (uuid {uid()}) {prop("Intersheetrefs","${INTERSHEET_REFS}",x,y,True)})')
def stub(n,x,y,dx):
 wire((x,y),(round(x+dx,3),y));label(n,round(x+dx,3),y)
def symbol(lib,ref,val,x,y,sim=None):
 props=prop('Reference',ref,x,y-8)+prop('Value',val,x,y+8)
 if sim:
  for k,v in sim.items():props+=prop(k,v,x,y,True)
 items.append(f'''(symbol (lib_id "Edu:{lib}") (at {x} {y} 0) (unit 1) (exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no) (uuid {uid()}) {props}
 (instances (project "triangle" (path "/{rootid}" (reference {q(ref)}) (unit 1)))))''')
def txt(s,x,y,size=1.27):items.append(f'(text {q(s)} (at {x} {y} 0) {effects(size)} (uuid {uid()}))')
sub={'Sim.Device':'SUBCKT','Sim.Library':'models.lib','Sim.Name':'EDU_OPAMP','Sim.Pins':'1=1 2=2 3=3'}
symbol('Amp','X1','A1: comparator',70,60,sub)
symbol('Amp','X2','A2: integrator',180,60,sub)
symbol('R','R3','1k',95,60);wire((77.62,60),(89.92,60));wire((100.08,60),(110,60))
wire((50,57.46),(62.38,57.46));wire((50,57.46),(50,115));label('UP',50,57.46)
stub('UN',62.38,62.54,-7.62)
symbol('R','R4','17.8k',140,62.54)
wire((110,60),(110,90));wire((110,62.54),(134.92,62.54));wire((145.08,62.54),(172.38,62.54))
label('SQ',110,60)
symbol('C','C1','10n',180,35,{'Sim.Device':'C','Sim.Params':'c=10n ic=0.01'})
wire((165,62.54),(165,35));wire((165,35),(174.92,35));wire((185.08,35),(205,35));wire((205,35),(205,115))
wire((187.62,60),(205,60));label('TRI',205,60)
wire((172.38,57.46),(170,57.46));wire((170,57.46),(170,80));label('US',170,80)
symbol('R','R2','20k',85,90);wire((50,90),(79.92,90));wire((90.08,90),(110,90))
symbol('R','R1','10k',135,115);wire((50,115),(129.92,115));wire((140.08,115),(205,115))
symbol('Clamp','X3','EDU_CLAMP',130,90,{'Sim.Device':'SUBCKT','Sim.Library':'models.lib','Sim.Name':'EDU_CLAMP','Sim.Pins':'1=1 2=2','Sim.Params':'UZP=5.1 UZM=5.1'})
wire((110,90),(124.92,90));stub('0',135.08,90,7.62)
for x,y in [(50,90),(110,62.54),(110,90),(165,62.54),(205,60)]:
 items.append(f'(junction (at {x} {y}) (diameter 0) (color 0 0 0 0) (uuid {uid()}))')
symbol('R','R5','10k',190,145);stub('US',184.92,145,-7.62);stub('0',195.08,145,7.62)
for ref,x,a in [('V1',65,'UN'),('V2',125,'US')]:
 symbol('V',ref,'0',x,145,{'Sim.Device':'V','Sim.Type':'DC','Sim.Params':'dc=0'})
 stub(a,x-5.08,145,-7.62);stub('0',x+5.08,145,7.62)
txt('Triangle / square wave oscillator | student 2025111871 | target 2800 Hz',125,16,1.8)
txt('TRI = uo; SQ = uo1. UN and US: ideal equivalents of potentiometer references.',125,23)
txt('Educational finite-gain amplifier, output +/-13.5V; idealized bidirectional clamp.',125,171)
txt('.tran 0.2u 8m uic',65,182)
txt('.options reltol=1e-5 abstol=1e-10 vntol=1e-7',125,190)
text=f'''(kicad_sch (version 20250114) (generator "eeschema") (uuid {rootid}) (paper "A4")
 (lib_symbols {''.join(libs)}) {''.join(items)})'''
text=text.replace('\"models.lib\"','\"${KIPRJMOD}/models.lib\"')
(ROOT/'triangle.kicad_sch').write_text(text)
(ROOT/'triangle.kicad_pro').write_text('{}\n')

# Save a standalone schematic for every parameter case.
import sys
sys.path.insert(0,str(ROOT/'tools'))
from run_all import CASES
(ROOT/'cases').mkdir(exist_ok=True)
for key,label,r1,r2,p,m,us,un in CASES:
 case_text=text.replace('(project "triangle"',f'(project "{key}"')
 case_text=case_text.replace('"${KIPRJMOD}/models.lib"','"${KIPRJMOD}/../models.lib"')
 case_text=case_text.replace('"UZP=5.1 UZM=5.1"',q(f'UZP={p} UZM={m}'))
 for ref,value in [('R1',str(r1)),('R2',str(r2)),('V1',str(un)),('V2',str(us))]:
  # Change just the instance property block, never the shared symbol library.
  start=case_text.index('(property "Reference" "'+ref+'"',case_text.index('(lib_id'))
  end=case_text.index('(instances',start)
  old=case_text[start:end]
  import re
  new=re.sub(r'(\(property "Value" )"[^"]*"',lambda m:m.group(1)+q(value),old,count=1)
  if ref.startswith('V'):new=new.replace('"dc=0"',q('dc='+value))
  case_text=case_text[:start]+new+case_text[end:]
 (ROOT/'cases'/f'{key}.kicad_sch').write_text(case_text)

 (ROOT/'cases'/f'{key}.kicad_pro').write_text('{}\n')
