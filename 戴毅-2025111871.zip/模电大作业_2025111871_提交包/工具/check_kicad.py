#!/usr/bin/env python3
"""Export each native schematic to SPICE and simulate its actual connections."""
import pathlib,subprocess,sys
from run_all import CASES,ROOT,measure,theory
for key,label,r1,r2,p,m,us,un in CASES:
 out=ROOT/'results'/f'kicad_{key}.cir'
 subprocess.run(['kicad-cli','sch','export','netlist','--format','spice','-o',str(out),str(ROOT/'cases'/f'{key}.kicad_sch')],check=True)
 net=out.read_text()
 net=net.replace('.end',f'''.control
run
set numdgt=15
set wr_singlescale
set wr_vecnames
wrdata results/kicad_{key}.dat v(TRI) v(SQ) v(UP)
quit
.endc
.end''')
 active=ROOT/'kicad_check.cir';active.write_text(net)
 proc=subprocess.run(['ngspice','-b',str(active)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (ROOT/'results'/f'kicad_{key}.log').write_text(proc.stdout)
 if 'aborted' in proc.stdout or proc.returncode:raise RuntimeError(proc.stdout)
 sim,_=measure(ROOT/'results'/f'kicad_{key}.dat'); th=theory(r1,r2,p,m,us,un)
 assert abs(sim['f']/th['f']-1)<.01,(key,sim,th)
 assert abs(sim['hi']-th['hi'])<.06 and abs(sim['lo']-th['lo'])<.06
 assert abs(sim['duty']-th['duty'])<.005
 print(f'{key}: KiCad connectivity + SPICE simulation PASS ({sim["f"]:.3f} Hz)')
(ROOT/'results'/'kicad_validation.txt').write_text('All 8 native KiCad schematics exported to SPICE and simulated successfully.\nFrequency error <1%, peak error <60mV, square duty error <0.5 percentage points.\n')
